import psutil
import pynvml
import json
import time
import serial  # pyserial kütüphanesi

# 1. Seri Port Bağlantısını Başlat
try:
    esp_port = serial.Serial()
    esp_port.port = 'COM4'
    esp_port.baudrate = 115200
    
    # ESP32'yi kilitlenmekten kurtaran sihirli ayarlar (Reset sinyallerini iptal et)
    esp_port.dtr = False
    esp_port.rts = False
    
    esp_port.open()
    print("ESP32 ile seri bağlantı başarıyla kuruldu!")
except Exception as e:
    print(f"Port Hatası: {e}")
    exit()

# 2. NVIDIA Kütüphanesini Başlat
pynvml.nvmlInit()
gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)

print("Veriler ESP32'ye akıyor... (Kapatmak için CTRL+C yapın)")

# 3. Sürekli Veri Akışı
while True:
    cpu_usage = psutil.cpu_percent(interval=1)
    ram_usage = psutil.virtual_memory().percent
    gpu_temp = pynvml.nvmlDeviceGetTemperature(gpu_handle, pynvml.NVML_TEMPERATURE_GPU)
    gpu_usage = pynvml.nvmlDeviceGetUtilizationRates(gpu_handle).gpu

    data = {
        "cu": cpu_usage,
        "ru": ram_usage,
        "gt": gpu_temp,
        "gu": gpu_usage
    }

    json_paket = json.dumps(data)
    
    # Veriyi ESP32'ye gönder.
    # C++ kodunda readStringUntil('\n') için paketin sonuna mutlaka \n.
    # ve utf-8 formatında byte'lara çevir.
    esp_port.write((json_paket + '\n').encode('utf-8'))
    
    # Aynı zamanda PC ekranına akış.
    print(f"Gönderilen: {json_paket}")